---
name: Further Information
order: 4
---

### Further Information

**SPOT FAQ**
- **Do routes ever change?**
    - Yes. Check SPOT App for route changes during high-traffic events like College Football Game Days. Routes are reconfigured to better serve the event and remote parking areas.
    - Check the SPOT App during inclement weather. Routes may be limited due to unfavorable road conditions.
    - Routes also may vary depending on the day of the week and time of day.
- **Will the SPOT App alert me to route changes?**
    - Yes. Follow the “Alerts” directions to enable route notifications.
- **How will I know if my bus is late?**
    - SPOT will alert you if a bus is behind schedule to your stop. Follow the “Alerts” directions to enable stop notifications.
    - You can also check the ETA of a bus to your stop by following directions for “Viewing stop information” or “Viewing bus information”.

**Applecart Website**  
For more information on AppalCART and the SPOT App, visit [ETA SPOT App (Live Transit) | AppalCART](https://www.appalcart.com/live-transit) 

