---
name: Tips and Tricks
order: 3
---

### Tips and Tricks

**Tip 1**  
- Google maps
- Choosing the Bus icon in Google Maps will also show bus routes and can give directions containing multiple routes.

**Tip 2**  
- When planning a trip destination, first select all routes to find the closest stop to your destination.

**Tip 3**  
- Favorite frequently visited stops to quickly get information on that stop
- Follow “Favoriting Stops” instructions to favorite and unfavorite stops.

**Tip 4**  
- AppalCART website
- Further information about routes can be found on the website:
    - Individual bus routes and schedules.
    - Inclimate weather and Game Day routes.
    - Route services.

**Tip 5**  
- Declutter the map by clicking on “Clear Map” or select fewer routes.
