---
name: SPOT Documentation
order: 1
---
# SPOT Documentation

## By: Team Penguin

### How to use the SPOT App for the Applecart Bus System

**About the App:**  
SPOT app is a real-time transit app that tracks bus routes and stops in your area via GPS. SPOT allows you to plan your trip and get information on various routes and ETAs based on your current location.

**The AppalCART System:**  
The AppalCART System is a free public transportation system, established in 1981, serving Boone, NC, App State campus and surrounding areas. AppalCART provides 13 fixed bus routes and 10 van routes as well as rural routes for those who qualify with Project on Aging.

### How to use this document

This document is a guide to using the SPOT transit App. Download the SPOT App. Scroll through this document to find steps on how to get started with the app, how to access information about the AppalCART transit system routes and stops, and how to use the various helpful features in the SPOT App.

### Materials list

- Smartphone (Android, IOS) or Tablet.
- GPS capabilities.
- WIFI or Cell data connection.
- SPOT App.