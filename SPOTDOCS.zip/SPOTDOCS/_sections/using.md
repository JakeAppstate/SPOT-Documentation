---
name: Using the App
order: 2
---

### Using the App

**Menu**  
- Click on the menu bar (upper left corner).  
- Selections include:
    - Select an Agency
    - Leave Feedback
    - Alerts
    - Notifications
    - Rate our App
    - Help

**Choosing a transit agency**  
- Click on “Select an Agency” within the menu.
- Click on the desired agency.

**Choosing a route**  
- Click on the “ROUTES” tab at the bottom icon bar to specify which route you would like the map to display.
- Click on the colored squares to select a route or routes from the “ROUTES” tab. A check will appear.
- Clicking “Select All” will select all the routes.
- Clicking “Deselect All” will remove all selections.
- Clicking on a route that has been checked will deselect the route.

**Viewing Route information**  
- Clicking on one of the “STOPS” buttons on the right-hand side within the “ROUTES” tab will show information about a route.
- Information includes:
    - List of stops.
    - Bus number en route.
    - ETA to stop.
    - Connecting routes at each stop.
- Clicking on “Back To Routes” on the left hand side will return to the “ROUTES” tab.

**Viewing a route**  
- Click on the “MAP” tab at the bottom icon bar to navigate to the map.
- When inside the Map tab, you can observe:
    - Where buses corresponding to the chosen routes are currently located.
    - The exact route outline the chosen bus takes to their prospective stops.
    - Each stop on the route is designated by colored dots.
    - Your current location is designated by a colored dot.
    - The map has user features similar to Google or Apple Maps.

**Viewing stop information**  
- Follow “Choosing a route” directions.
- Follow “Viewing a route” directions.
- Click on a stop (colored “dot” button) within the route.
- Stop information window includes:
    - Name of stop.
    - All routes that connect to that stop.
    - Each bus currently en route to that stop.
    - Bus ETA.
    - “DIRECTIONS FROM HERE” button.
    - “Add to Favorites button”.
- Click on the “X” in the top right corner to close the window.

**Viewing bus information**  
- Follow “Choosing a route” directions.
- Follow “Viewing a route” directions.
- Click on a bus (colored bus icon) within a route.
- Bus information includes:
    - Bus number.
    - ETA and location of next three stops.

**Trip planning**  
- Follow “Viewing stop information” directions.
- Plan a trip to a specific stop.
- Click on ”DIRECTIONS FROM HERE” within the stop information window.
- Google or Apple maps will open with directions to the selected stop.
- Plan a trip to a destination
    - Click on the “Filter By” drop down.
    - Select a type of destination.
    - Choose a route and stop nearest to the destination.

**Favoriting Stops**  
- Follow “Viewing stop information” directions.
- Click the “ADD TO FAVORITES” button.
- Exit the stop information window by clicking the “X” in the top right.
- Favorited spots will be marked as a star.
- Click the “VIEW FAVORITES” button in the top right of the map screen.
- Information shown on the “Favorite Stations/ Stops” window includes:
    - Stop Name.
    - All routes that connect to that stop.
    - Each bus currently en route to that stop.
    - ETA of buses arriving to the stop.
- To unfavorite a stop
    - Click on stop to be unfavorited on the map screen.
    - Click the “ADD TO FAVORITES” button.
    - Ensure the star to the left of the button is not filled in.

**Alerts**  
- To avoid missing a bus you can receive bus route, stop and trip alerts.
- Click on “Notifications” within the menu.
- Click on the buttons to the right to activate an alert.
- Click on a dropdown to select a specific route, stop or trip.
- Enable notifications.